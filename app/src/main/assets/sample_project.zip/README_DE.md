# MinePhone Overlay – Android-Prototyp

## Was dieses Projekt macht
- Stellt ein hochkantiges, schwebendes MinePhone-Fenster dar.
- Das Fenster lässt sich am oberen Balken verschieben.
- Ein Button öffnet die installierte WhatsApp-App.
- Das Overlay lässt sich schließen.

## Wichtige Einschränkung
Das ist **kein** eingebettetes WhatsApp-Fenster. Android-Apps können die private WhatsApp-Oberfläche nicht einfach in eine andere App einbetten. Beim Tippen auf „WhatsApp öffnen“ wechselt Android zur offiziellen WhatsApp-App. Ein echter GTA-artiger Bildschirm mit vollständiger WhatsApp-Bedienung innerhalb von Minecraft ist mit einem normalen MCPE-Addon nicht direkt möglich.

## Bauen
1. Projekt in Android Studio öffnen.
2. Gradle-Synchronisierung abwarten.
3. Build > Build APK(s) auswählen.
4. Die APK liegt normalerweise unter `app/build/outputs/apk/debug/`.

## Testen auf Android
1. APK installieren.
2. MinePhone Overlay öffnen.
3. „Über anderen Apps einblenden erlauben“ aktivieren.
4. Zur App zurückkehren und „MinePhone-Fenster starten“ drücken.
5. Minecraft öffnen. Auf manchen Geräten/Versionen kann Android Overlays über Vollbildspielen einschränken.

## Hinweise
- Dies ist Quellcode, keine bereits gebaute oder getestete APK.
- Das Projekt benötigt Android Studio/Android SDK zum Bauen.
- Es liest keine WhatsApp-Nachrichten und speichert keine privaten Chatdaten.
